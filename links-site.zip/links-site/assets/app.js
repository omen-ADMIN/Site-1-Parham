(function (global) {
  "use strict";

  var TWEET_RE = /(?:https?:\/\/)?(?:www\.)?(?:twitter|x)\.com\/([^/?#]+)\/status(?:es)?\/(\d+)/i;
  var ITEMS_URL = "data/items.json";

  function sha256hex(text) {
    var bytes = new TextEncoder().encode(text);
    return crypto.subtle.digest("SHA-256", bytes).then(function (buffer) {
      var array = new Uint8Array(buffer);
      var hex = "";
      for (var i = 0; i < array.length; i += 1) {
        hex += array[i].toString(16).padStart(2, "0");
      }
      return hex;
    });
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function isHttpUrl(value) {
    try {
      var url = new URL(value);
      return url.protocol === "http:" || url.protocol === "https:";
    } catch (err) {
      return false;
    }
  }

  function parseTweet(url) {
    var match = String(url || "").match(TWEET_RE);
    if (!match) return null;
    return {
      user: match[1],
      id: match[2],
      twitterUrl: "https://twitter.com/" + match[1] + "/status/" + match[2],
      xUrl: "https://x.com/" + match[1] + "/status/" + match[2]
    };
  }

  function config() {
    return global.SITE_CONFIG || {};
  }

  function applySiteMeta() {
    var cfg = config();
    var title = document.getElementById("site-title");
    var description = document.getElementById("site-description");
    if (title && cfg.SITE_NAME) title.textContent = cfg.SITE_NAME;
    if (description && cfg.SITE_DESCRIPTION) description.textContent = cfg.SITE_DESCRIPTION;
  }

  function renderLinkCard(item) {
    var desc = item.description
      ? '<p class="desc">' + escapeHtml(item.description) + "</p>"
      : "";
    return (
      '<article class="item-card">' +
        '<span class="badge">پیوند</span>' +
        "<h2>" + escapeHtml(item.title || item.url) + "</h2>" +
        desc +
        '<a class="card-link" href="' + escapeHtml(item.url) + '" rel="noopener noreferrer" target="_blank">باز کردن پیوند</a>' +
      "</article>"
    );
  }

  function renderXCard(item) {
    var tweet = parseTweet(item.url);
    var desc = item.description
      ? '<p class="desc">' + escapeHtml(item.description) + "</p>"
      : "";
    var fallbackHref = escapeHtml((tweet && tweet.xUrl) || item.url);
    var embedHref = escapeHtml((tweet && tweet.twitterUrl) || item.url);
    var title = escapeHtml(item.title || "پست در X");
    var embed = tweet
      ? '<div class="twitter-embed">' +
          '<blockquote class="twitter-tweet" data-dnt="true" data-lang="fa">' +
            "<p>" + title + "</p>" +
            '<a href="' + embedHref + '">مشاهده پست در X</a>' +
          "</blockquote>" +
        "</div>"
      : "";
    return (
      '<article class="item-card">' +
        '<span class="badge">پست X</span>' +
        "<h2>" + title + "</h2>" +
        desc +
        embed +
        '<p><a class="card-link" href="' + fallbackHref + '" rel="noopener noreferrer" target="_blank">اگر پست جاسازی نشد، این پیوند را باز کنید</a></p>' +
      "</article>"
    );
  }

  function renderItems(container, items) {
    if (!container) return;
    var list = Array.isArray(items) ? items : [];
    if (!list.length) {
      container.innerHTML = '<p class="empty">هنوز موردی اضافه نشده است.</p>';
      return;
    }
    container.innerHTML = list.map(function (item) {
      if (item && item.type === "x") return renderXCard(item);
      return renderLinkCard(item || {});
    }).join("");
    loadTweetWidgets(container);
  }

  function loadTweetWidgets(scope) {
    function run() {
      if (global.twttr && global.twttr.widgets && typeof global.twttr.widgets.load === "function") {
        global.twttr.widgets.load(scope || document);
        return true;
      }
      return false;
    }
    if (global.twttr && typeof global.twttr.ready === "function") {
      global.twttr.ready(function () { run(); });
      return;
    }
    if (run()) return;
    var started = Date.now();
    var timer = setInterval(function () {
      if (run() || Date.now() - started > 8000) clearInterval(timer);
    }, 200);
  }

  function extractItems(data) {
    if (Array.isArray(data)) return data;
    if (data && Array.isArray(data.items)) return data.items;
    return [];
  }

  function loadItems() {
    return fetch(ITEMS_URL, { cache: "no-store" }).then(function (response) {
      if (!response.ok) {
        throw new Error("Failed to load items.json: " + response.status);
      }
      return response.json();
    }).then(extractItems);
  }

  function initPublicPage() {
    applySiteMeta();
    var root = document.getElementById("items");
    loadItems().then(function (items) {
      renderItems(root, items);
    }).catch(function () {
      if (root) {
        root.innerHTML = '<p class="empty">بارگذاری فهرست انجام نشد. لطفاً صفحه را تازه کنید.</p>';
      }
    });
  }

  global.LinksSite = {
    sha256hex: sha256hex,
    escapeHtml: escapeHtml,
    isHttpUrl: isHttpUrl,
    parseTweet: parseTweet,
    renderItems: renderItems,
    loadItems: loadItems,
    extractItems: extractItems,
    loadTweetWidgets: loadTweetWidgets
  };

  document.addEventListener("DOMContentLoaded", function () {
    if (document.body && document.body.getAttribute("data-page") === "public") {
      initPublicPage();
    }
  });
})(window);
