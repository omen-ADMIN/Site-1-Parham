(function (global) {
  "use strict";

  var DRAFT_KEY = "links-site-draft";
  var GH_KEY = "links-site-github";
  var AUTH_KEY = "links-site-auth";
  var site = global.LinksSite;

  var items = [];
  var dirty = false;

  function $(id) {
    return document.getElementById(id);
  }

  function expectedHash() {
    return String((global.SITE_CONFIG || {}).ADMIN_PASSWORD_HASH || "").trim().toLowerCase();
  }

  function showNotice(id, text, kind) {
    var el = $(id);
    if (!el) return;
    if (!text) {
      el.hidden = true;
      el.textContent = "";
      return;
    }
    el.hidden = false;
    el.textContent = text;
    el.classList.remove("warning");
    if (kind === "warning") el.classList.add("warning");
  }

  function isAuthed() {
    return sessionStorage.getItem(AUTH_KEY) === "1";
  }

  function setAuthed(value) {
    if (value) sessionStorage.setItem(AUTH_KEY, "1");
    else sessionStorage.removeItem(AUTH_KEY);
  }

  function newId() {
    if (global.crypto && typeof global.crypto.randomUUID === "function") {
      return global.crypto.randomUUID();
    }
    return "item-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
  }

  function payload() {
    return { items: items };
  }

  function prettyJson() {
    return JSON.stringify(payload(), null, 2) + "\n";
  }

  function saveDraft() {
    localStorage.setItem(DRAFT_KEY, prettyJson());
    dirty = true;
  }

  function readDraft() {
    try {
      var raw = localStorage.getItem(DRAFT_KEY);
      if (!raw) return null;
      return site.extractItems(JSON.parse(raw));
    } catch (err) {
      return null;
    }
  }

  function renderList() {
    var list = $("item-list");
    if (!list) return;
    if (!items.length) {
      list.innerHTML = '<li class="empty">پیش‌نویس خالی است.</li>';
      return;
    }
    list.innerHTML = items.map(function (item, index) {
      var typeLabel = item.type === "x" ? "پست X" : "پیوند";
      return (
        '<li class="item-row" data-index="' + index + '">' +
          '<p class="title">' + site.escapeHtml(item.title || "(بدون عنوان)") + " · " + typeLabel + "</p>" +
          '<p class="url">' + site.escapeHtml(item.url) + "</p>" +
          '<div class="row-actions">' +
            '<button type="button" class="btn btn-ghost" data-action="up"' + (index === 0 ? " disabled" : "") + ">بالا</button>" +
            '<button type="button" class="btn btn-ghost" data-action="down"' + (index === items.length - 1 ? " disabled" : "") + ">پایین</button>" +
            '<button type="button" class="btn btn-danger" data-action="delete">حذف</button>' +
          "</div>" +
        "</li>"
      );
    }).join("");
  }

  function renderPreview() {
    site.renderItems($("preview"), items);
  }

  function refresh() {
    renderList();
    renderPreview();
  }

  function moveItem(index, delta) {
    var next = index + delta;
    if (next < 0 || next >= items.length) return;
    var copy = items[index];
    items[index] = items[next];
    items[next] = copy;
    saveDraft();
    refresh();
  }

  function deleteItem(index) {
    var item = items[index];
    var label = item && item.title ? item.title : "این مورد";
    if (!confirm("«" + label + "» حذف شود؟")) return;
    items.splice(index, 1);
    saveDraft();
    refresh();
    showNotice("admin-status", "مورد حذف شد و پیش‌نویس ذخیره شد.");
  }

  function loadFromSite(force) {
    return site.loadItems().then(function (list) {
      items = list.slice();
      if (force) {
        localStorage.setItem(DRAFT_KEY, prettyJson());
      }
      dirty = false;
      refresh();
      showNotice("admin-status", "فهرست از data/items.json بارگذاری شد.");
    }).catch(function () {
      items = [];
      refresh();
      showNotice("admin-status", "خواندن فایل سایت ممکن نشد. می‌توانید از صفر پیش‌نویس بسازید.", "warning");
    });
  }

  function downloadItems() {
    var blob = new Blob([prettyJson()], { type: "application/json;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    var link = document.createElement("a");
    link.href = url;
    link.download = "items.json";
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    showNotice("admin-status", "فایل دانلود شد. آن را جای data/items.json بگذارید و سایت را دوباره منتشر کنید.");
  }

  function utf8ToBase64(text) {
    var bytes = new TextEncoder().encode(text);
    var binary = "";
    for (var i = 0; i < bytes.length; i += 1) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  function readGithubForm() {
    return {
      owner: $("gh-owner").value.trim(),
      repo: $("gh-repo").value.trim(),
      branch: $("gh-branch").value.trim() || "main",
      path: $("gh-path").value.trim() || "data/items.json",
      token: $("gh-token").value.trim()
    };
  }

  function fillGithubForm() {
    try {
      var saved = JSON.parse(localStorage.getItem(GH_KEY) || "{}");
      if (saved.owner) $("gh-owner").value = saved.owner;
      if (saved.repo) $("gh-repo").value = saved.repo;
      if (saved.branch) $("gh-branch").value = saved.branch;
      if (saved.path) $("gh-path").value = saved.path;
      if (saved.token) $("gh-token").value = saved.token;
    } catch (err) {
      // ignore broken storage
    }
  }

  function persistGithubForm(data, keepToken) {
    localStorage.setItem(GH_KEY, JSON.stringify({
      owner: data.owner,
      repo: data.repo,
      branch: data.branch,
      path: data.path,
      token: keepToken ? data.token : ""
    }));
  }

  function githubHeaders(token) {
    return {
      Accept: "application/vnd.github+json",
      Authorization: "Bearer " + token,
      "X-GitHub-Api-Version": "2022-11-28"
    };
  }

  function publishToGithub(event) {
    event.preventDefault();
    var data = readGithubForm();
    var status = $("github-status");
    status.hidden = false;
    if (!data.owner || !data.repo || !data.token) {
      status.textContent = "مالک مخزن، نام مخزن و توکن را وارد کنید.";
      return;
    }
    persistGithubForm(data, true);
    status.textContent = "در حال انتشار…";
    var api = "https://api.github.com/repos/" + encodeURIComponent(data.owner) + "/" + encodeURIComponent(data.repo) + "/contents/" + data.path.split("/").map(encodeURIComponent).join("/");
    var headers = githubHeaders(data.token);

    fetch(api + "?ref=" + encodeURIComponent(data.branch), { headers: headers }).then(function (response) {
      if (response.ok) return response.json();
      if (response.status === 404) return null;
      return response.json().catch(function () { return {}; }).then(function (body) {
        var message = (body && body.message) || ("خطای گیت‌هاب: " + response.status);
        throw new Error(message);
      });
    }).then(function (existing) {
      var body = {
        message: "Update data/items.json",
        content: utf8ToBase64(prettyJson()),
        branch: data.branch
      };
      if (existing && existing.sha) body.sha = existing.sha;
      return fetch(api, {
        method: "PUT",
        headers: Object.assign({ "Content-Type": "application/json" }, headers),
        body: JSON.stringify(body)
      });
    }).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (body) {
        if (!response.ok) {
          throw new Error((body && body.message) || ("انتشار ناموفق بود: " + response.status));
        }
        dirty = false;
        status.textContent = "منتشر شد. پس از بازسازی GitHub Pages، صفحهٔ عمومی موارد جدید را نشان می‌دهد.";
        showNotice("admin-status", "انتشار در گیت‌هاب انجام شد.");
      });
    }).catch(function (err) {
      status.textContent = "انتشار انجام نشد: " + (err && err.message ? err.message : "خطای ناشناخته");
    });
  }

  function onAddItem(event) {
    event.preventDefault();
    var type = $("item-type").value;
    var url = $("item-url").value.trim();
    var title = $("item-title").value.trim();
    var description = $("item-description").value.trim();

    if (!site.isHttpUrl(url)) {
      showNotice("admin-status", "نشانی باید با http یا https شروع شود.", "warning");
      return;
    }
    if (type === "x" && !site.parseTweet(url)) {
      showNotice("admin-status", "برای پست X باید پیوندی مثل https://x.com/user/status/123 باشد.", "warning");
      return;
    }
    if (!title) {
      showNotice("admin-status", "عنوان را وارد کنید.", "warning");
      return;
    }

    items.push({
      id: newId(),
      type: type,
      title: title,
      url: url,
      description: description,
      createdAt: new Date().toISOString()
    });
    saveDraft();
    refresh();
    event.target.reset();
    $("item-type").value = type;
    showNotice("admin-status", "به پیش‌نویس اضافه شد. برای دیده شدن در سایت عمومی، فایل را دانلود و جایگزین کنید یا در گیت‌هاب منتشر کنید.");
  }

  function showApp() {
    $("login-panel").hidden = true;
    $("admin-app").hidden = false;
    fillGithubForm();

    var draft = readDraft();
    if (draft && draft.length) {
      items = draft;
      dirty = true;
      refresh();
      showNotice("draft-banner", "پیش‌نویس ذخیره‌شده در همین مرورگر بارگذاری شد. اگر می‌خواهید نسخهٔ منتشرشده را ببینید، «بارگذاری از فایل سایت» را بزنید.");
    } else {
      loadFromSite(false);
    }
  }

  function bindApp() {
    $("item-form").addEventListener("submit", onAddItem);
    $("item-list").addEventListener("click", function (event) {
      var button = event.target.closest("button[data-action]");
      if (!button) return;
      var row = button.closest("[data-index]");
      if (!row) return;
      var index = Number(row.getAttribute("data-index"));
      var action = button.getAttribute("data-action");
      if (action === "up") moveItem(index, -1);
      if (action === "down") moveItem(index, 1);
      if (action === "delete") deleteItem(index);
    });
    $("reload-site-btn").addEventListener("click", function () {
      if (dirty && !confirm("پیش‌نویس فعلی با فایل منتشرشده جایگزین شود؟")) return;
      showNotice("draft-banner", "");
      loadFromSite(true);
    });
    $("download-btn").addEventListener("click", downloadItems);
    $("github-form").addEventListener("submit", publishToGithub);
    $("clear-token-btn").addEventListener("click", function () {
      var data = readGithubForm();
      data.token = "";
      $("gh-token").value = "";
      persistGithubForm(data, false);
      showNotice("admin-status", "توکن از این مرورگر پاک شد.");
    });
    $("logout-btn").addEventListener("click", function () {
      setAuthed(false);
      location.reload();
    });
  }

  function initLogin() {
    $("login-form").addEventListener("submit", function (event) {
      event.preventDefault();
      var error = $("login-error");
      error.hidden = true;
      var password = $("password").value;
      var expected = expectedHash();
      if (!expected) {
        error.textContent = "هش رمز در config.js تنظیم نشده است.";
        error.hidden = false;
        return;
      }
      site.sha256hex(password).then(function (hash) {
        if (hash !== expected) {
          error.textContent = "رمز نادرست است.";
          error.hidden = false;
          return;
        }
        setAuthed(true);
        showApp();
      }).catch(function () {
        error.textContent = "بررسی رمز ممکن نشد. صفحه را با http یا https باز کنید، نه به‌صورت فایل محلی.";
        error.hidden = false;
      });
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (!document.body || document.body.getAttribute("data-page") !== "admin") return;
    if (!site) return;
    initLogin();
    bindApp();
    if (isAuthed()) showApp();
  });
})(window);
