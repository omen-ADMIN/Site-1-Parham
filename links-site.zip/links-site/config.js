/**
 * تنظیمات سایت.
 * قبل از انتشار، مقدار SITE_ORIGIN را با دامنهٔ واقعی جایگزین کنید.
 * هش رمز پیش‌فرض مربوط به «changeme» است؛ حتماً آن را عوض کنید.
 * این قفل فقط سمت مرورگر است و امنیت واقعی به‌شمار نمی‌رود.
 */
window.SITE_CONFIG = {
  SITE_NAME: "پیوندهای پرهام",
  SITE_DESCRIPTION: "مجموعه‌ای از پیوندها و پست‌های منتخب پرهام.",
  SITE_ORIGIN: "https://YOUR-USERNAME.github.io/YOUR-REPO",
  ADMIN_PASSWORD_HASH: "057ba03d6c44104863dc7361fe4578965d1887360f90a0895882e58a6248fc86"
};
